import { Route, Routes } from 'react-router-dom';
import './App.css';
import HomePage from './Components/HomePage';
import Navbar from './Components/Navbar';
import Edit from './Components/Edit';
import Show from './Components/Show';

function App() {
  return (
    <>
    <Navbar/>
    <Routes>
      <Route path='/' element={<HomePage/>}/>
      <Route path='/show' element={<Show/>}/>
      <Route path='/edit/:id' element={<Edit/>}/>
    </Routes>
    </>
  );
}

export default App;
