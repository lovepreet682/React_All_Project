import axios from 'axios';
const API_URL = "http://localhost:8090";

class Student_Service {
    saveStudent(student) {
        return axios.post(API_URL + "/saveStudent", student);
    }

    getAllStudent() {
        return axios.get(API_URL + "/list");
    }

    getStudentById(id) {
        return axios.get(API_URL + "/list/" + id);
    }

    deleteStudent(id) {
        return axios.delete(API_URL + "/delete/"+id);
    }

    editStudent(student) {
        return axios.put(API_URL + "/updateStudent/" + student.id, student);
    }
}
export default new Student_Service();