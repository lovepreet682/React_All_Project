import axios from "axios";

const API_URL = "http://localhost:4000";

class student_node{
    saveStudent(student) {
        return axios.post(API_URL + "/users", student);
    }

    getAllStudent() {
        return axios.get(API_URL + "/users");
    }

    getStudentById(id) {
        return axios.get(API_URL + "/users/" + id);
    }

    deleteStudent(id) {
        return axios.delete(API_URL + "/users/"+id);
    }

    editStudent(student) {
        return axios.put(API_URL + "/users/" + student.id, student);
    }
}
export default new student_node();