import React, { useEffect, useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import { useNavigate, useParams } from 'react-router-dom';
// import Student_Service from '../Service/Student_Service';
import Student_node from '../Service/Student_node';

function Edit() {
    const [student, setStudent] = useState({
        id:"",
        name: "",
        email: "",
        age: "",
        city: "Select the City",
    });

    //print the message
    const [message, setMesaage] = useState("")
    const navigate=useNavigate();

    //Get the Id
    const { id } = useParams();
    console.log(id);

    const handleChange = (e) => {
        e.preventDefault();
        console.log("Button is ")
        const value = e.target.value;
        setStudent({ ...student, [e.target.name]: value });
    }

    //use Effect for getting the Id
    useEffect(() => {
        Student_node.getStudentById(id).then((res) => {
            setStudent(res.data);
        }).catch((error) => {
            console.log(error)
        })
    },[id])

    
    //Node Js Edit Button 
    const studentUpdate = async (e) => {
        e.preventDefault();
        console.log("Click Button Working")
        try{
            Student_node.editStudent(student).then((res)=>{
                console.log("Value Saved");
                setMesaage("Edit Data Successfully");
                navigate("/show")
            })
        }catch(error){
            console.log(error)
        }
    }
        
    return (
        <>
            <div className="pt-5" id='form_Section'>
                <h5 className='text-center text-white mb-2'>Edit Your Details</h5>
                {
                    message && <div class="alert alert-success w-50 m-auto mb-3" role="alert">{message}</div>
                }
                <Form className='form_section' onSubmit={(e) => studentUpdate(e)} >
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Enter Name</Form.Label>
                        <Form.Control type="text" name='name' placeholder="Enter Your Name" onChange={(e) => handleChange(e)} value={student.name} required/>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" name='email' placeholder="name@example.com" onChange={(e) => handleChange(e)} value={student.email} required/>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Age</Form.Label>
                        <Form.Control type="number" name='age' placeholder="Enter Age" onChange={(e) => handleChange(e)} value={student.age} required/>
                    </Form.Group>

                    <Form.Group className='mb-3' controlId="">
                        <Form.Label>City</Form.Label>

                        <Form.Select aria-label="Select The City" name='city' onChange={(e) => handleChange(e)} value={student.city} required>
                            <option>Select the City</option>
                            <option value="Amritsar">Amritsar</option>
                            <option value="Jalandhar">Jalandhar</option>
                            <option value="Gurdaspur">Gurdaspur</option>
                            <option value="Noida">Noida</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Other City">Other City</option>
                        </Form.Select>
                    </Form.Group>

                    <div className="button-Section text-center">
                        <Button variant="danger" style={{ width: '120px' }} className='' type='submit' onClick={(e) => handleChange(e)}>Update</Button>
                        <Button variant="dark mx-4" style={{ width: '120px' }} type='reset'>Reset</Button>
                        <Button variant="success" style={{ width: '120px' }} type=''>Back</Button>
                    </div>
                </Form>
            </div>
        </>
    )
}

export default Edit