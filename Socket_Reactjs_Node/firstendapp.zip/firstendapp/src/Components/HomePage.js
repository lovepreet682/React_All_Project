import React, { useState } from 'react'
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
// import Student_Service from '../Service/Student_Service';
import Student_node from '../Service/Student_node';

function HomePage() {
    const [student, setStudent] = useState({
        name: "",
        email: "",
        age: "",
        city: "",
    });

    const handleChange = (e) => {
        const value = e.target.value;
        setStudent({ ...student, [e.target.name]: value });
    };

    //for Message
    const [message, setMesaage] = useState("");


    const studentRegister = (e) => {
        e.preventDefault();
        Student_node.saveStudent(student).then((res) => {
            setMesaage("Data Successfully Saved")
            setStudent({
                name: "",
                email: "",
                age: "",
                city: "",
            });

            setTimeout(() => {
                setMesaage("");
              }, 2000);
        }).catch((error) => {
            console.log(error);
        })
    }
    return (
        <>
            <div className="pt-5" id='form_Section'>
            <h4 className='text-center text-white'>Enter Your Details</h4>
                {
                    message && <div class="alert alert-danger w-50 m-auto mb-3" role="alert">{message}</div>
                }

                <Form onSubmit={(e) => studentRegister(e)} className='form_section' >
                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Enter Name</Form.Label>
                        <Form.Control type="text" placeholder="Enter Your Name" name='name' onChange={(e) => handleChange(e)} value={student.name} required/>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Email address</Form.Label>
                        <Form.Control type="email" placeholder="name@example.com" name='email' onChange={(e) => handleChange(e)} value={student.email} required/>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                        <Form.Label>Age</Form.Label>
                        <Form.Control type="number" placeholder="Enter Age" name='age' onChange={(e) => handleChange(e)} value={student.age} required/>
                    </Form.Group>

                    <Form.Group className='mb-3' controlId="">
                        <Form.Label>City</Form.Label>

                        <Form.Select aria-label="Select The City" name='city' onChange={(e) => handleChange(e)} value={student.city} required>
                            <option>Select the City</option>
                            <option value="Amritsar">Amritsar</option>
                            <option value="Jalandhar">Jalandhar</option>
                            <option value="Gurdaspur">Gurdaspur</option>
                            <option value="Noida">Noida</option>
                            <option value="Delhi">Delhi</option>
                            <option value="Other City">Other City</option>
                        </Form.Select>
                    </Form.Group>

                    <div className="button-Section text-center">
                        <Button variant="danger" style={{ width: '120px' }} className='' type='submit' >Register</Button>
                        <Button variant="dark mx-4" style={{ width: '120px' }} type='reset'>Reset</Button>
                        <Button variant="success" style={{ width: '120px' }} type=' '>Back</Button>
                    </div>
                </Form>

            </div>
        </>
    )
}

export default HomePage