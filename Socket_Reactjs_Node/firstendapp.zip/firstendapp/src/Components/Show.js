import React, { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Table from 'react-bootstrap/Table';
// import Student_Service from '../Service/Student_Service';
import { Link } from 'react-router-dom';
import Student_node from '../Service/Student_node';
function Show() {

  const [studentList, setStudentList] = useState([]);
  const [message, setMesaage] = useState("");

  useEffect(() => {
    init();
  }, []);

  //delete student method
  const deleteStudent = (id) => {
    console.log("You CLick the Value")
    Student_node.deleteStudent(id).then((res) => {
      setMesaage("Data Deleted Successfully")
      init();

      //print the message
      setTimeout(() => {
        setMesaage("");
      }, 2000);


    }).catch((error) => {
      console.log(error);
    });
  };


  //It will reload the data and show data
  const init = () => {
    Student_node.getAllStudent().then((res) => {
      setStudentList(res.data);
    }).catch((error) => {
      console.log(error);
    });
  }

  return (
    <>
      <div className="container text-center">
        <h2 className='pt-4 pb-2 text-center'>Student Details Section</h2>

        {/* Delete the Message */}
        {message && <div class="alert alert-danger" role="alert">
          {message}
        </div>}

        <Table striped bordered hover size="sm">
          <thead>
            <tr>
              <th>Student ID</th>
              <th> Name</th>
              <th>Email</th>
              <th>Age</th>
              <th>City</th>
              <th>Operation</th>
            </tr>
          </thead>
          <tbody>
            {studentList.map((s) => (
              <tr>
                <td>{s.id}</td>
                <td>{s.name}</td>
                <td>{s.email}</td>
                <td>{s.age}</td>
                <td>{s.city}</td>
                <td><Link to={'/edit/' + s.id} className='btn btn-danger mx-2' >Edit</Link>
                  <Button variant="warning" onClick={() => deleteStudent(s.id)}>Delete</Button>
                </td>
              </tr>
            ))
            };
          </tbody>
        </Table>
      </div>
    </>
  )
}

export default Show